#include <stdlib.h>
#include <board.h>
#include <systick.h>
#include <timer.h>
#include <event.h>
#include "buzzer.h"

int main(void)
{
	board_init();
	systick_init();
	timer_init();
	beep_init();
	beep_start(500, 50);
	event_poll();
	return 0;
}
