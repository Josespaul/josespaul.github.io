= I2C Device Firmware

This project contains the firmware for the I2C LCD and Keypad slave
devices. These slave devices are used as part of the Linux Device
Driver course, to teach device driver programming.
