#ifndef BUZZER_H
#define BUZZER_H

/* Single Beep

 * ->|  |<- duration
 *  _||||________

 * Produces a single beep for given duration.
 */
void beep_single(int duration);

/* call back function for duration timer.
 * Once the timer expires, this function is called, which turns off the beep.
 */
static void beep_single_done(timer_t *timer);

/* call back function for period timer.
 * First time the function is called by 'beep_start' and then the function is
 * Called when the duration timer expires, producing short beeps continuously.
 * Beeps are stopped by calleing beep_stop.
 */
static void beep_continuous(timer_t *timer);

/* stops the beep by stoping the timers.*/
void beep_stop(void);

/* Continuous Beeps
 *
 * _||||_________||||_______
 *  |<- period ->|
 * Produces single beeps continuously for given time interval(period).
 */
void beep_start(int period, int duration);

/* beep initialisation is done here.*/
void beep_init(void);

#endif
