#include <pwm.h>
#include <timer.h>
#include "buzzer.h"

static timer_t period_timer;
static timer_t duration_timer;
static int cnt_beep_period;
static int cnt_beep_duration;

/* Produces a single beep for given duration. */
void beep_single(int duration)
{
	pwm_start(PWM_CH5);
	timer_setup(&duration_timer, duration);
}

/* call back function for duration timer.*/
static void beep_single_done(timer_t *timer)
{
	pwm_stop(PWM_CH5);
	timer_ack(timer);
}

/* call back function for period timer.*/
static void beep_continuous(timer_t *timer)
{
	beep_single(cnt_beep_duration);
	timer_setup(timer, cnt_beep_period);
}

/* stops the beep by stoping the timers.*/
void beep_stop(void)
{
	timer_ack(&period_timer);
	timer_ack(&duration_timer);
}

/* Continuous Beeps
 *
 * _||||_________||||_______
 *  |<- period ->|
 * Produces single beeps continuously for given time interval(period).
 */
void beep_start(int period, int duration)
{
	cnt_beep_period = period;
	cnt_beep_duration = duration;

	beep_continuous(&period_timer);
}

/* beep initialisation is done here.*/
void beep_init(void)
{
	timer_setcb(&duration_timer, (event_xhandle_t)beep_single_done);
	timer_setcb(&period_timer, (event_xhandle_t)beep_continuous);

	timer_ack(&period_timer);
	timer_ack(&duration_timer);

	pwm_init();

	pwm_set_frequency(PWM_CH5, 800);
	pwm_set_duty(PWM_CH5, 50);
}
